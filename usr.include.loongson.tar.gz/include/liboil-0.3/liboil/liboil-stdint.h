#ifndef _LIBOIL_LIBOIL_LIBOIL_STDINT_H
#define _LIBOIL_LIBOIL_LIBOIL_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "liboil 0.3.16"
/* generated using gnu compiler gcc (GCC) 4.9.3 20150626 (NeoKylin 4.9.3-3) */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
